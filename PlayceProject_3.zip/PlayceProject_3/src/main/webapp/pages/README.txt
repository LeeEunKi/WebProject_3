.property-item .property-content .price span {
      position: relative;
      padding-bottom: 4px;
      display: inline-block; }
      .property-item .property-content .price span:after {
        position: absolute;
        content: "";
        width: 100%;
        height: 2px;
        left: 0;
        bottom: 0;
        background-color: #F78104; }